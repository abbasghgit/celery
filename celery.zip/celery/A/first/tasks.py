from celery import shared_task
import random
from .models import *
import time

@shared_task
def my_task():
    f = random.randint(1000 ,100000)
    time.sleep(20)
    t = Todo.objects.create(name = f)
    t.save()