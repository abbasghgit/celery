from django.urls import path
from .views import *
urlpatterns = [
    path('', ModelView.as_view() ,name='todo'),
]
