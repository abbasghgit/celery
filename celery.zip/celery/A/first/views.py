from django.shortcuts import render
from django.views import View
from .models import *
# Create your views here.
class ModelView(View):
    template_name = 'first/first.html'
    def get(self ,request):
        todos = Todo.objects.all()
        context = {
            'todos': todos,
        }
        return render(request ,self.template_name ,context)